# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap, NumberActionMap
from Components.Label import Label
from Components.config import config, ConfigSubsection, ConfigText, ConfigSelection, ConfigNumber
from Components.ScrollLabel import ScrollLabel
from Components.Button import Button
from Components.Sources.StaticText import StaticText
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox
from Screens.ChoiceBox import ChoiceBox
import subprocess
import re
import os
import socket
from enigma import eTimer, getDesktop, eSize, ePoint
from twisted.web.client import getPage
from twisted.python import failure

config.plugins.UniversalCamConfig = ConfigSubsection()
config.plugins.UniversalCamConfig.username = ConfigText(default="", fixed_size=False)
config.plugins.UniversalCamConfig.password = ConfigText(default="", fixed_size=False)
config.plugins.UniversalCamConfig.protocol = ConfigSelection(default="cccam", choices=[
    ("cccam", "CCCam"),
    ("newcamd", "Newcamd"),
    ("cccam-s", "CCCam (SSL)"),
    ("newcamd-s", "Newcamd (SSL)"),
    ("mgcamd", "MGcamd")
])
config.plugins.UniversalCamConfig.destination = ConfigSelection(default="oscam", choices=[
    ("oscam", "OSCam"),
    ("ncam", "NCam"),
    ("mgcamd", "MGcamd")
])
config.plugins.UniversalCamConfig.server_host = ConfigText(default="", fixed_size=False)
config.plugins.UniversalCamConfig.server_port = ConfigNumber(default=12000)
config.plugins.UniversalCamConfig.des_key = ConfigText(default="0102030405060708091011121314", fixed_size=False)
config.plugins.UniversalCamConfig.label = ConfigText(default="My Cam Server", fixed_size=False)
config.plugins.UniversalCamConfig.enable = ConfigSelection(default="1", choices=[("1", "Yes"), ("0", "No")])

OSCAM_PATH = "/etc/tuxbox/config/oscam.server"
NCAM_PATH = "/etc/tuxbox/config/ncam.server"
MGCAMD_PATH = "/usr/keys/newcamd.list"
INSTALLER_PATH = "/tmp/installer.sh"

class VirtualKeyboard(Screen):
    skin = """
    <screen name="VirtualKeyboard" position="center,center" size="1150,600" title="Virtual Keyboard">
        <eLabel position="10,10" size="1130,580" backgroundColor="#2d2d2d" zPosition="-1" />
        
        <widget name="title_label" position="30,20" size="1090,40" font="Regular;28" halign="center" valign="center" foregroundColor="#FFD700" transparent="1" />
        
        <widget name="input_field" position="30,70" size="1090,50" font="Regular;30" halign="left" valign="center" backgroundColor="#3A3A3A" foregroundColor="#FFFFFF" transparent="0" />
        
        <widget name="cursor_indicator" position="0,0" size="110,60" backgroundColor="#FF0000" zPosition="1" transparent="0" />
        
        <widget source="key_00" render="Label" position="30,140" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_01" render="Label" position="140,140" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_02" render="Label" position="250,140" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_03" render="Label" position="360,140" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_04" render="Label" position="470,140" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_05" render="Label" position="580,140" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_06" render="Label" position="690,140" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_07" render="Label" position="800,140" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_08" render="Label" position="910,140" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_09" render="Label" position="1020,140" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        
        <widget source="key_10" render="Label" position="30,200" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_11" render="Label" position="140,200" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_12" render="Label" position="250,200" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_13" render="Label" position="360,200" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_14" render="Label" position="470,200" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_15" render="Label" position="580,200" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_16" render="Label" position="690,200" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_17" render="Label" position="800,200" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_18" render="Label" position="910,200" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_19" render="Label" position="1020,200" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        
        <widget source="key_20" render="Label" position="30,260" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_21" render="Label" position="140,260" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_22" render="Label" position="250,260" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_23" render="Label" position="360,260" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_24" render="Label" position="470,260" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_25" render="Label" position="580,260" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_26" render="Label" position="690,260" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_27" render="Label" position="800,260" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_28" render="Label" position="910,260" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_29" render="Label" position="1020,260" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        
        <widget source="key_30" render="Label" position="30,320" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_31" render="Label" position="140,320" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_32" render="Label" position="250,320" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_33" render="Label" position="360,320" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_34" render="Label" position="470,320" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_35" render="Label" position="580,320" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_36" render="Label" position="690,320" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_37" render="Label" position="800,320" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_38" render="Label" position="910,320" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_39" render="Label" position="1020,320" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        
        <widget source="key_40" render="Label" position="30,380" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_41" render="Label" position="140,380" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_42" render="Label" position="250,380" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_43" render="Label" position="360,380" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_44" render="Label" position="470,380" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_45" render="Label" position="580,380" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_46" render="Label" position="690,380" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_47" render="Label" position="800,380" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_48" render="Label" position="910,380" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        <widget source="key_49" render="Label" position="1020,380" size="100,50" font="Regular;28" halign="center" valign="center" zPosition="2" backgroundColor="#21000000" foregroundColor="#FFFFFF" />
        
        <widget name="mode_label" position="30,440" size="300,30" font="Regular;22" halign="left" valign="center" foregroundColor="#CCCCCC" transparent="1" />
        
        <widget name="cursor_info" position="352,440" size="400,30" font="Regular;22" halign="center" valign="center" foregroundColor="#FFD700" transparent="1" />
        
        <widget name="key_red" position="30,490" size="250,40" font="Regular;26" halign="center" valign="center" backgroundColor="#9F1313" foregroundColor="#FFFFFF" transparent="0" text="Backspace" />
        <widget name="key_green" position="310,490" size="250,40" font="Regular;26" halign="center" valign="center" backgroundColor="#1F771F" foregroundColor="#FFFFFF" transparent="0" text="Space" />
        <widget name="key_yellow" position="590,490" size="250,40" font="Regular;26" halign="center" valign="center" backgroundColor="#A08500" foregroundColor="#FFFFFF" transparent="0" text="Clear" />
        <widget name="key_blue" position="870,490" size="250,40" font="Regular;26" halign="center" valign="center" backgroundColor="#000080" foregroundColor="#FFFFFF" transparent="0" text="Close" />
    </screen>"""
    
    def __init__(self, session, current_text="", title="Enter Text", callback=None):
        Screen.__init__(self, session)
        self.session = session
        self.current_text = current_text
        self.title_text = title
        self.callback = callback
        self.keyboard_mode = "lower" 
        self.current_row = 0
        self.current_col = 0
        
        self.keyboards = {
            "lower": [
                ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
                ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
                ["a", "s", "d", "f", "g", "h", "j", "k", "l", "."],
                ["z", "x", "c", "v", "b", "n", "m", ",", "-", "_"],
                ["@", "Shift", "Sym", "123", "<--", "Space", "Done", "", "", ""]
            ],
            "upper": [
                ["!", "@", "#", "$", "%", "^", "&", "*", "(", ")"],
                ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
                ["A", "S", "D", "F", "G", "H", "J", "K", "L", ":"],
                ["Z", "X", "C", "V", "B", "N", "M", ";", "+", "="],
                ["~", "shift", "Sym", "123", "<--", "Space", "Done", "", "", ""]
            ],
            "symbols": [
                ["[", "]", "{", "}", "<", ">", "|", "\\", "/", "?"],
                ["!", "@", "#", "$", "%", "^", "&", "*", "(", ")"],
                ["`", "~", "_", "-", "+", "=", "{", "}", "[", "]"],
                [":", ";", "\"", "'", ",", ".", "<", ">", "/", "?"],
                ["ABC", "Shift", "sym", "123", "<--", "Space", "Done", "", "", ""]
            ],
            "numbers": [
                ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
                [".", ":", ",", ";", "-", "_", "+", "=", "(", ")"],
                ["/", "\\", "|", "[", "]", "{", "}", "<", ">", "&"],
                ["#", "@", "!", "?", "%", "^", "*", "~", "`", "$"],
                ["ABC", "Shift", "Sym", "123", "<--", "Space", "Done", "", "", ""]
            ]
        }
        
        self.key_widgets = {}
        for row in range(5):
            for col in range(10):
                key_name = f"key_{row}{col}"
                self[key_name] = StaticText("")
                self.key_widgets[(row, col)] = key_name
        
        self["title_label"] = Label(title)
        self["input_field"] = Label(self.current_text)
        self["mode_label"] = Label("Mode: Lowercase")
        self["cursor_info"] = Label("Pos: Row 0, Col 0")
        self["key_red"] = Label("Backspace")
        self["key_green"] = Label("Space")
        self["key_yellow"] = Label("Clear")
        self["key_blue"] = Label("Close")
        
        self["cursor_indicator"] = Label("")
        
        self["actions"] = ActionMap(
            ["WizardActions", "ColorActions", "DirectionActions"],
            {
                "ok": self.keyOk,
                "back": self.keyCancel,
                "left": self.keyLeft,
                "right": self.keyRight,
                "up": self.keyUp,
                "down": self.keyDown,
                "red": self.keyBackspace,
                "green": self.keySpace,
                "yellow": self.keyClear,
                "blue": self.keyCancel,
            },
            -1
        )
        
        self.setTitle("Virtual Keyboard")
        self.onLayoutFinish.append(self.buildKeyboard)
    
    def buildKeyboard(self):
        self.updateKeyboardDisplay()
    
    def updateKeyboardDisplay(self):
        try:
            keyboard = self.keyboards[self.keyboard_mode]
            
            mode_labels = {
                "lower": "Mode: Lowercase",
                "upper": "Mode: Uppercase", 
                "symbols": "Mode: Symbols",
                "numbers": "Mode: Numbers"
            }
            self["mode_label"].setText(mode_labels.get(self.keyboard_mode, "Mode: Lowercase"))
            
            self["cursor_info"].setText(f"Pos: Row {self.current_row+1}, Col {self.current_col+1}")
            
            cursor_x = 30 + (self.current_col * 110) - 5
            cursor_y = 140 + (self.current_row * 60) - 5
            
            if 0 <= cursor_x <= 1140 and 0 <= cursor_y <= 560:
                self["cursor_indicator"].instance.resize(eSize(110, 60))
                self["cursor_indicator"].instance.move(ePoint(cursor_x, cursor_y))
                self["cursor_indicator"].show()
            
            for row in range(5):
                for col in range(10):
                    key_name = self.key_widgets[(row, col)]
                    if col < len(keyboard[row]):
                        char = keyboard[row][col]
                        self[key_name].text = char
                    else:
                        self[key_name].text = ""
            
            self["input_field"].setText(self.current_text)
            
        except Exception as e:
            print(f"Update keyboard display error: {e}")
    
    def keyLeft(self):
        try:
            if self.current_col > 0:
                self.current_col -= 1
            else:
                self.current_col = 9  # أقصى اليمين
            self.updateKeyboardDisplay()
        except Exception as e:
            print(f"Key left error: {e}")
    
    def keyRight(self):
        try:
            if self.current_col < 9:
                self.current_col += 1
            else:
                self.current_col = 0  
            self.updateKeyboardDisplay()
        except Exception as e:
            print(f"Key right error: {e}")
    
    def keyUp(self):
        try:
            if self.current_row > 0:
                self.current_row -= 1
            else:
                self.current_row = 4  
            self.updateKeyboardDisplay()
        except Exception as e:
            print(f"Key up error: {e}")
    
    def keyDown(self):
        try:
            if self.current_row < 4:
                self.current_row += 1
            else:
                self.current_row = 0  
            self.updateKeyboardDisplay()
        except Exception as e:
            print(f"Key down error: {e}")
    
    def keyOk(self):
        try:
            keyboard = self.keyboards[self.keyboard_mode]
            if self.current_row < len(keyboard) and self.current_col < len(keyboard[self.current_row]):
                key = keyboard[self.current_row][self.current_col]
                
                if key == "Shift" or key == "shift":
                    self.toggleShift()
                elif key == "Sym" or key == "sym":
                    self.switchToSymbols()
                elif key == "123":
                    self.switchToNumbers()
                elif key == "ABC":
                    self.switchToLower()
                elif key == "<--":
                    self.keyBackspace()
                elif key == "Space":
                    self.keySpace()
                elif key == "Done":
                    self.keyEnter()
                elif key != "":
                    self.insertCharacter(key)
        except Exception as e:
            print(f"Key OK error: {e}")
    
    def insertCharacter(self, char):
        try:
            self.current_text += str(char)
            self["input_field"].setText(self.current_text)
            self.updateKeyboardDisplay()
        except Exception as e:
            print(f"Insert character error: {e}")
    
    def toggleShift(self):
        if self.keyboard_mode == "lower":
            self.keyboard_mode = "upper"
        elif self.keyboard_mode == "upper":
            self.keyboard_mode = "lower"
        self.current_row = 0
        self.current_col = 0
        self.updateKeyboardDisplay()
    
    def switchToSymbols(self):
        self.keyboard_mode = "symbols"
        self.current_row = 0
        self.current_col = 0
        self.updateKeyboardDisplay()
    
    def switchToNumbers(self):
        self.keyboard_mode = "numbers"
        self.current_row = 0
        self.current_col = 0
        self.updateKeyboardDisplay()
    
    def switchToLower(self):
        self.keyboard_mode = "lower"
        self.current_row = 0
        self.current_col = 0
        self.updateKeyboardDisplay()
    
    def keyBackspace(self):
        if len(self.current_text) > 0:
            self.current_text = self.current_text[:-1]
            self["input_field"].setText(self.current_text)
            self.updateKeyboardDisplay()
    
    def keySpace(self):
        self.current_text += " "
        self["input_field"].setText(self.current_text)
        self.updateKeyboardDisplay()
    
    def keyClear(self):
        self.current_text = ""
        self["input_field"].setText(self.current_text)
        self.updateKeyboardDisplay()
    
    def keyEnter(self):
        if self.callback:
            self.callback(self.current_text)
        self.close(self.current_text)
    
    def keyCancel(self):
        self.close(None)

class UniversalCamConfigGridScreen(Screen):
    CURRENT_VERSION = "2.1"
    VERSION_URL = "https://raw.githubusercontent.com/Ham-ahmed/UniversalCamConfig/refs/heads/main/version.txt"
    INSTALLER_URL = "https://raw.githubusercontent.com/Ham-ahmed/Universal/refs/heads/main/UniversalCam.sh"

    skin = """
    <screen name="UniversalCamConfigGridScreen" position="center,center" size="1500,740" title="Universal Cam Config V2.1" backgroundColor="#1A1A1A">

        <eLabel position="20,20" size="1476,710" backgroundColor="#21000000" zPosition="-2" />
        
        <widget name="title_info_label" position="57,30" size="1200,90" font="Regular;28" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#3A3A3A" transparent="0" />
        
        <eLabel position="20,130" size="1480,2" backgroundColor="#FFD700" zPosition="-1" />
        <eLabel position="20,700" size="1480,2" backgroundColor="#FFD700" zPosition="-1" />
        
        <widget name="label_label" position="60,155" size="205,40" font="Regular;26" halign="left" valign="center" foregroundColor="#fcfdfd" transparent="1" />
        <widget name="label_value" position="290,155" size="240,40" font="Regular; 24" halign="left" valign="center" backgroundColor="#160000" foregroundColor="#FFFFFF" transparent="1" />
        <widget name="label_edit" position="543,155" size="100,40" font="Regular;24" halign="center" valign="center" backgroundColor="#160000" foregroundColor="#FFFFFF" transparent="1" text="Edit" />
        
        <widget name="protocol_label" position="655,155" size="205,40" font="Regular;26" halign="left" valign="center" foregroundColor="#FFD700" transparent="1" />
        <widget name="protocol_value" position="890,155" size="250,40" font="Regular;26" halign="left" valign="center" backgroundColor="#160000" foregroundColor="#49bbff" transparent="1" />
        <widget name="protocol_edit" position="1151,155" size="100,40" font="Regular;24" halign="center" valign="center" backgroundColor="#160000" foregroundColor="#FFFFFF" transparent="1" text="Select" />
        
        <widget name="server_host_label" position="60,220" size="205,40" font="Regular;26" halign="left" valign="center" foregroundColor="#fcfdfd" transparent="1" />
        <widget name="server_host_value" position="290,220" size="240,40" font="Regular; 24" halign="left" valign="center" backgroundColor="#160000" foregroundColor="#7fff00" transparent="1" />
        <widget name="server_host_edit" position="545,220" size="100,40" font="Regular;24" halign="center" valign="center" backgroundColor="#160000" foregroundColor="#FFFFFF" transparent="1" text="Edit" />
        
        <widget name="server_port_label" position="655,220" size="205,40" font="Regular;26" halign="left" valign="center" foregroundColor="#FFD700" transparent="1" />
        <widget name="server_port_value" position="890,220" size="250,40" font="Regular;26" halign="left" valign="center" backgroundColor="#21000000" foregroundColor="#7fff00" transparent="1" />
        <widget name="server_port_edit" position="1151,215" size="100,40" font="Regular;24" halign="center" valign="center" backgroundColor="#160000" foregroundColor="#FFFFFF" transparent="1" text="Edit" />
        
        <widget name="username_label" position="60,275" size="205,40" font="Regular;26" halign="left" valign="center" foregroundColor="#fcfdfd" transparent="1" />
        <widget name="username_value" position="292,275" size="240,40" font="Regular; 24" halign="left" valign="center" backgroundColor="#160000" foregroundColor="#FFD700" transparent="1" />
        <widget name="username_edit" position="545,275" size="100,40" font="Regular;24" halign="center" valign="center" backgroundColor="#160000" foregroundColor="#FFFFFF" transparent="1" text="Edit" />
        
        <widget name="password_label" position="655,275" size="205,40" font="Regular;26" halign="left" valign="center" foregroundColor="#FFD700" transparent="1" />
        <widget name="password_value" position="890,275" size="250,40" font="Regular;26" halign="left" valign="center" backgroundColor="#160000" foregroundColor="#92f1fc" transparent="1" />
        <widget name="password_edit" position="1151,275" size="100,40" font="Regular;24" halign="center" valign="center" backgroundColor="#160000" foregroundColor="#FFFFFF" transparent="1" text="Edit" />
        
        <widget name="des_key_label" position="60,390" size="205,40" font="Regular;26" halign="left" valign="center" foregroundColor="#fcfdfd" transparent="1" />
        <widget name="des_key_value" position="300,390" size="811,40" font="Regular;26" halign="center" valign="center" backgroundColor="#2A2A2A" foregroundColor="#FFFFFF" transparent="1" />
        <widget name="des_key_edit" position="1153,390" size="100,40" font="Regular;24" halign="center" valign="center" backgroundColor="#160000" foregroundColor="#FFFFFF" transparent="1" text="Edit" />
        
        <widget name="destination_label" position="657,335" size="205,40" font="Regular;26" halign="left" valign="center" foregroundColor="#FFD700" transparent="1" />
        <widget name="destination_value" position="890,335" size="250,40" font="Regular;26" halign="left" valign="center" backgroundColor="#160000" foregroundColor="#FFFFFF" transparent="1" />
        <widget name="destination_edit" position="1151,335" size="100,40" font="Regular;24" halign="center" valign="center" backgroundColor="#160000" foregroundColor="#FFFFFF" transparent="1" text="Select" />
        
        <widget name="enable_label" position="60,335" size="205,40" font="Regular;26" halign="left" valign="center" foregroundColor="#fcfdfd" transparent="1" />
        <widget name="enable_value" position="290,335" size="240,40" font="Regular; 24" halign="left" valign="center" backgroundColor="#160000" foregroundColor="#f3fc92" transparent="1" />
        <widget name="enable_edit" position="545,335" size="100,40" font="Regular;24" halign="center" valign="center" backgroundColor="#160000" foregroundColor="#FFFFFF" transparent="1" text="Toggle" />
        
        <widget name="keyboard_button_label" position="60,450" size="500,40" font="Regular;26" halign="center" valign="center" foregroundColor="#00BFFF" transparent="1" text="Virtual Keyboard (Press OK)" />
        
        <widget name="status_label" position="60,510" size="500,40" font="Regular;24" halign="center" valign="center" foregroundColor="#CCCCCC" transparent="1" />
        
        <widget name="version_label" position="60,560" size="500,30" font="Regular;22" halign="center" valign="center" foregroundColor="#CCCCCC" transparent="1" />
        <widget name="update_status_label" position="60,600" size="500,30" font="Regular;22" halign="center" valign="center" foregroundColor="#CCCCCC" transparent="1" />
        
        <widget name="connection_status" position="60,650" size="1070,40" font="Regular; 24" halign="center" valign="center" foregroundColor="#FFD700" transparent="1" />
        
        <widget name="key_yellow" position="1278,306" size="200,50" font="Regular;28" halign="center" valign="center" backgroundColor="#A08500" transparent="0" cornerRadius="5" foregroundColor="#FFFFFF" text="Test" />
        <widget name="key_blue" position="1278,379" size="200,50" font="Regular;28" halign="center" valign="center" backgroundColor="#000080" transparent="0" cornerRadius="5" foregroundColor="#FFFFFF" text="Clear All" />
        <widget name="key_red" position="1278,453" size="200,50" font="Regular;28" halign="center" valign="center" backgroundColor="#9F1313" transparent="0" cornerRadius="5" foregroundColor="#FFFFFF" text="Delete" />
        <widget name="key_green" position="1278,529" size="200,50" font="Regular;28" halign="center" valign="center" backgroundColor="#1F771F" transparent="0" cornerRadius="5" foregroundColor="#FFFFFF" text="Save" />
        
        <widget font="Regular;30" foregroundColor="#b8860b" backgroundColor="#160000" halign="center" position="1312,173" render="Label" size="143,52" source="global.CurrentTime" transparent="1" valign="center" zPosition="5">
            <convert type="ClockToText">Default</convert>
        </widget>
        <widget source="global.CurrentTime" render="Label" position="1278,214" size="210,52" font="Regular;28" halign="center" foregroundColor="#b8860b" backgroundColor="#160000" transparent="1" zPosition="6">
            <convert type="ClockToText">Format:%d.%m.%Y</convert>
        </widget>
        
        <ePixmap name="" position="1289,39" size="180,72" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Universal Cam Config/icons/uni.png" scale="1" />
        
        <eLabel position="55,145" size="1200,2" backgroundColor="#FFD700" zPosition="-1" /> <!-- خط أفقي أول -->
        <eLabel position="55,205" size="1200,2" backgroundColor="#FFD700" zPosition="-1" /> <!-- خط أفقي ثاني -->
        <eLabel position="55,265" size="1200,2" backgroundColor="#FFD700" zPosition="-1" /> <!-- خط أفقي ثالث -->
        <eLabel position="55,325" size="1200,2" backgroundColor="#FFD700" zPosition="-1" /> <!-- خط أفقي رابع -->
        <eLabel position="55,385" size="1200,2" backgroundColor="#FFD700" zPosition="-1" /> <!-- خط أفقي خامس -->
        
        <eLabel position="55,145" size="2,290" backgroundColor="#FFD700" zPosition="-1" /> <!-- خط عمودي أول -->
        <eLabel position="283,145" size="2,290" backgroundColor="#FFD700" zPosition="-1" /> <!-- خط عمودي ثاني -->
        <eLabel position="538,145" size="2,240" backgroundColor="#FFD700" zPosition="-1" /> <!-- خط عمودي ثالث -->
        <eLabel position="645,145" size="2,240" backgroundColor="#FFD700" zPosition="-1" /> <!-- خط عمودي رابع -->
        <eLabel position="882,145" size="2,240" backgroundColor="#FFD700" zPosition="-1" /> <!-- خط عمودي خامس -->
        <eLabel position="1145,145" size="2,290" backgroundColor="#FFD700" zPosition="-1" /> <!-- خط عمودي سادس -->
        <eLabel position="55,435" size="1200,2" backgroundColor="#FFD700" zPosition="-1" />
        <eLabel position="1256,145" size="2,290" backgroundColor="#FFD700" zPosition="-1" />
        
        <widget name="cursor_visual" position="-3,-12" size="10,10" backgroundColor="#FF0000" zPosition="-1" cornerRadius="5" transparent="0" />
  </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        self.temp_label = config.plugins.UniversalCamConfig.label.value
        self.temp_enable = config.plugins.UniversalCamConfig.enable.value
        self.temp_protocol = config.plugins.UniversalCamConfig.protocol.value
        self.temp_server_host = config.plugins.UniversalCamConfig.server_host.value
        self.temp_server_port = str(config.plugins.UniversalCamConfig.server_port.value)
        self.temp_username = config.plugins.UniversalCamConfig.username.value
        self.temp_password = config.plugins.UniversalCamConfig.password.value
        self.temp_des_key = config.plugins.UniversalCamConfig.des_key.value
        self.temp_destination = config.plugins.UniversalCamConfig.destination.value
        
        self.protocol_choices = dict(config.plugins.UniversalCamConfig.protocol.choices.choices)
        self.destination_choices = dict(config.plugins.UniversalCamConfig.destination.choices.choices)
        self.enable_choices = dict(config.plugins.UniversalCamConfig.enable.choices.choices)

        self["key_red"] = Label("Delete")
        self["key_green"] = Label("Save")
        self["key_yellow"] = Label("Test")
        self["key_blue"] = Label("Clear All")
        self["status_label"] = Label("Ready")
        self["connection_status"] = Label("")
        
        self["title_info_label"] = Label(
            "Universal Cam Config V2.1\nPlugin Interface for Easy Configuration By Hamdy Ahmed"
        )
        
        self["label_label"] = Label("Label:")
        self["enable_label"] = Label("Enable:")
        self["protocol_label"] = Label("Protocol:")
        self["server_host_label"] = Label("Server Host:")
        self["server_port_label"] = Label("Server Port:")
        self["username_label"] = Label("Username:")
        self["password_label"] = Label("Password:")
        self["des_key_label"] = Label("DES Key:")
        self["destination_label"] = Label("Destination:")
        
        self["label_value"] = Label(self.temp_label)
        self["enable_value"] = Label(self.enable_choices.get(self.temp_enable, "Yes"))
        self["protocol_value"] = Label(self.protocol_choices.get(self.temp_protocol, "CCCam"))
        self["server_host_value"] = Label(self.temp_server_host)
        self["server_port_value"] = Label(self.temp_server_port)
        self["username_value"] = Label(self.temp_username)
        self["password_value"] = Label(self.temp_password)
        self["des_key_value"] = Label(self.temp_des_key)
        self["destination_value"] = Label(self.destination_choices.get(self.temp_destination, "OSCam"))
        
        self["label_edit"] = Label("Edit")
        self["enable_edit"] = Label("Toggle")
        self["protocol_edit"] = Label("Select")
        self["server_host_edit"] = Label("Edit")
        self["server_port_edit"] = Label("Edit")
        self["username_edit"] = Label("Edit")
        self["password_edit"] = Label("Edit")
        self["des_key_edit"] = Label("Edit")
        self["destination_edit"] = Label("Select")
        
        self["keyboard_button_label"] = Label("Virtual Keyboard (Press OK)")
        
        self["version_label"] = Label("Current Version: %s" % self.CURRENT_VERSION)
        self["update_status_label"] = Label("")
        
        self["cursor_visual"] = Label("")
        
        self.grid_positions = {
            "label": {"x": 290, "y": 160, "w": 240, "h": 40, "row": 0, "col": 0, "button": "label_edit", "button_x": 540, "button_y": 160},
            "protocol": {"x": 890, "y": 160, "w": 250, "h": 40, "row": 0, "col": 1, "button": "protocol_edit", "button_x": 1145, "button_y": 160},
            "server_host": {"x": 290, "y": 220, "w": 240, "h": 40, "row": 1, "col": 0, "button": "server_host_edit", "button_x": 540, "button_y": 220},
            "server_port": {"x": 890, "y": 220, "w": 250, "h": 40, "row": 1, "col": 1, "button": "server_port_edit", "button_x": 1145, "button_y": 215},
            "username": {"x": 292, "y": 275, "w": 240, "h": 40, "row": 2, "col": 0, "button": "username_edit", "button_x": 540, "button_y": 275},
            "password": {"x": 890, "y": 275, "w": 250, "h": 40, "row": 2, "col": 1, "button": "password_edit", "button_x": 1145, "button_y": 275},
            "enable": {"x": 290, "y": 335, "w": 240, "h": 40, "row": 4, "col": 0, "button": "enable_edit", "button_x": 540, "button_y": 335},
            "destination": {"x": 890, "y": 335, "w": 250, "h": 40, "row": 3, "col": 1, "button": "destination_edit", "button_x": 1145, "button_y": 335},
            "des_key": {"x": 300, "y": 390, "w": 826, "h": 40, "row": 3, "col": 0, "button": "des_key_edit", "button_x": 1145, "button_y": 390},
            "keyboard": {"x": 60, "y": 450, "w": 500, "h": 40, "row": 5, "col": 0},
        }
        
        self.grid_items = [
            {"name": "label", "row": 0, "col": 0, "type": "field"},
            {"name": "protocol", "row": 0, "col": 1, "type": "field"},
            {"name": "server_host", "row": 1, "col": 0, "type": "field"},
            {"name": "server_port", "row": 1, "col": 1, "type": "field"},
            {"name": "username", "row": 2, "col": 0, "type": "field"},
            {"name": "password", "row": 2, "col": 1, "type": "field"},
            {"name": "enable", "row": 4, "col": 0, "type": "field"},
            {"name": "destination", "row": 3, "col": 1, "type": "field"},
            {"name": "des_key", "row": 3, "col": 0, "type": "field"},
            {"name": "keyboard", "row": 5, "col": 0, "type": "button"},
        ]
        
        self.current_row = 0
        self.current_col = 0
        self.current_field = "label"
        self.focus_mode = "value"
        self.highlight_color = "#FF0000"  
        
        self["actions"] = ActionMap(
            ["WizardActions", "ColorActions", "DirectionActions", "MenuActions"],
            {
                "ok": self.keyOk,
                "back": self.close,
                "green": self.saveConfig,
                "red": self.keyDelete,
                "yellow": self.testConnection,
                "blue": self.clearAllFields,
                "up": self.keyUp,
                "down": self.keyDown,
                "left": self.keyLeft,
                "right": self.keyRight,
                "menu": self.showMainMenu,
            },
            -1,
        )
        
        self.flickerTimer = eTimer()
        self.flickerTimer.callback.append(self.flickerEffect)
        self.flicker_on = False
        
        self.onLayoutFinish.append(self.updateFocus)

    def updateFocus(self):
        try:
            if self.flickerTimer:
                self.flickerTimer.stop()
            self.flicker_on = False
            
            current_item = None
            for item in self.grid_items:
                if item["row"] == self.current_row and item["col"] == self.current_col:
                    current_item = item
                    break
            
            if current_item:
                self.current_field = current_item["name"]
                
                if self.current_field in self.grid_positions:
                    pos = self.grid_positions[self.current_field]
                    
                    if self.focus_mode == "button" and "button" in pos:
                        cursor_x = pos["button_x"] - 5
                        cursor_y = pos["button_y"] - 5
                        cursor_w = 100 + 10  
                        cursor_h = 40 + 10   
                    else:
                        cursor_x = pos["x"] - 5
                        cursor_y = pos["y"] - 5
                        cursor_w = pos["w"] + 10
                        cursor_h = pos["h"] + 10
                    
                    if cursor_x > 0 and cursor_y > 0:
                        self["cursor_visual"].instance.resize(eSize(cursor_w, cursor_h))
                        self["cursor_visual"].instance.move(ePoint(cursor_x, cursor_y))
                        self["cursor_visual"].show()
                
                if self.current_field == "keyboard":
                    self["status_label"].setText("Virtual Keyboard - Press OK to open")
                else:
                    self["status_label"].setText(f"Selected: {self.current_field.replace('_', ' ').title()}")
            
            if self.flickerTimer:
                self.flickerTimer.start(500, True)
                
        except Exception as e:
            print(f"Update focus error: {e}")

    def flickerEffect(self):
        try:
            self.flicker_on = not self.flicker_on
            
            if self.flicker_on:
                self["cursor_visual"].instance.setBackgroundColor(0x800000)  # أحمر غامق
            else:
                self["cursor_visual"].instance.setBackgroundColor(0xFF0000)  # أحمر
            
            self.flickerTimer.start(500, True)
                
        except Exception as e:
            print(f"Flicker effect error: {e}")

    def keyUp(self):
        try:
            candidates = []
            for item in self.grid_items:
                if item["col"] == self.current_col and item["row"] < self.current_row:
                    candidates.append(item)
            
            if candidates:
                candidates.sort(key=lambda x: x["row"], reverse=True)
                self.current_row = candidates[0]["row"]
                self.current_col = candidates[0]["col"]
                self.updateFocus()
        except Exception as e:
            print(f"Key up error: {e}")

    def keyDown(self):
        try:
            candidates = []
            for item in self.grid_items:
                if item["col"] == self.current_col and item["row"] > self.current_row:
                    candidates.append(item)
            
            if candidates:
                candidates.sort(key=lambda x: x["row"])
                self.current_row = candidates[0]["row"]
                self.current_col = candidates[0]["col"]
                self.updateFocus()
        except Exception as e:
            print(f"Key down error: {e}")

    def keyLeft(self):
        try:
            if self.focus_mode == "button" and self.current_field in self.grid_positions:
                if "button" in self.grid_positions[self.current_field]:
                    self.focus_mode = "value"
                    self.updateFocus()
            else:
                candidates = []
                for item in self.grid_items:
                    if item["row"] == self.current_row and item["col"] < self.current_col:
                        candidates.append(item)
                
                if candidates:
                    candidates.sort(key=lambda x: x["col"], reverse=True)
                    self.current_row = candidates[0]["row"]
                    self.current_col = candidates[0]["col"]
                    self.focus_mode = "value"
                    self.updateFocus()
        except Exception as e:
            print(f"Key left error: {e}")

    def keyRight(self):
        try:
            if self.focus_mode == "value" and self.current_field in self.grid_positions:
                if "button" in self.grid_positions[self.current_field]:
                    self.focus_mode = "button"
                    self.updateFocus()
            else:
                candidates = []
                for item in self.grid_items:
                    if item["row"] == self.current_row and item["col"] > self.current_col:
                        candidates.append(item)
                
                if candidates:
                    candidates.sort(key=lambda x: x["col"])
                    self.current_row = candidates[0]["row"]
                    self.current_col = candidates[0]["col"]
                    self.focus_mode = "value"
                    self.updateFocus()
        except Exception as e:
            print(f"Key right error: {e}")

    def keyOk(self):
        try:
            if not self.current_field:
                return
            
            if self.current_field == "keyboard":
                self.openVirtualKeyboardForCurrentField()
                return
            
            if self.current_field in self.grid_positions:
                if self.focus_mode == "value":
                    self.openVirtualKeyboardForField(self.current_field)
                elif self.focus_mode == "button":
                    if self.current_field in ["protocol", "destination"]:
                        self.openChoiceMenu(self.current_field)
                    elif self.current_field == "enable":
                        self.toggleEnable()
                    else:
                        self.openVirtualKeyboardForField(self.current_field)
            
        except Exception as e:
            print(f"Key OK error: {e}")
            self.session.open(MessageBox, f"Error in key OK: {str(e)}", MessageBox.TYPE_ERROR)

    def openVirtualKeyboardForCurrentField(self):
        try:
            if not self.current_field:
                return
            
            if self.current_field == "keyboard":
                self.selectFieldForKeyboard()
            else:
                self.openVirtualKeyboardForField(self.current_field)
        except Exception as e:
            print(f"Open virtual keyboard for current field error: {e}")

    def openVirtualKeyboardForField(self, field_name):
        try:
            current_value = getattr(self, f"temp_{field_name}", "")
            
            field_titles = {
                "label": "Enter Label",
                "server_host": "Enter Server Host",
                "server_port": "Enter Server Port",
                "username": "Enter Username",
                "password": "Enter Password",
                "des_key": "Enter DES Key",
            }
            title = field_titles.get(field_name, "Enter Text")
            
            def keyboardCallback(result):
                if result is not None:
                    try:
                        setattr(self, f"temp_{field_name}", str(result))
                        self.updateFieldValue(field_name, str(result))
                        self["status_label"].setText(f"Field '{field_name}' updated")
                    except Exception as e:
                        print(f"Virtual keyboard callback error: {e}")
            
            self.session.openWithCallback(
                keyboardCallback,
                VirtualKeyboard,
                current_text=current_value,
                title=title
            )
        except Exception as e:
            print(f"Open virtual keyboard for field error: {e}")
            self.openSimpleKeyboard(field_name)

    def openSimpleKeyboard(self, field_name):
        try:
            current_value = getattr(self, f"temp_{field_name}", "")
            field_titles = {
                "label": "Enter Label",
                "server_host": "Enter Server Host",
                "server_port": "Enter Server Port",
                "username": "Enter Username",
                "password": "Enter Password",
                "des_key": "Enter DES Key",
            }
            title = field_titles.get(field_name, "Enter Text")
            
            def simpleKeyboardCallback(result):
                if result is not None:
                    setattr(self, f"temp_{field_name}", str(result))
                    self.updateFieldValue(field_name, str(result))
                    self["status_label"].setText(f"Field '{field_name}' updated")
            
            self.session.openWithCallback(
                simpleKeyboardCallback,
                InputBox,
                title=title,
                text=current_value,
                maxSize=False
            )
        except Exception as e:
            print(f"Open simple keyboard error: {e}")

    def selectFieldForKeyboard(self):
        try:
            fields = [
                ("Label", "label"),
                ("Server Host", "server_host"),
                ("Server Port", "server_port"),
                ("Username", "username"),
                ("Password", "password"),
                ("DES Key", "des_key"),
            ]
            
            def fieldSelected(result):
                if result:
                    self.openVirtualKeyboardForField(result[1])
            
            self.session.openWithCallback(
                fieldSelected,
                ChoiceBox,
                title="Select Field for Keyboard",
                list=fields
            )
        except Exception as e:
            print(f"Select field for keyboard error: {e}")

    def updateFieldValue(self, field_name, value):
        try:
            if field_name == "label":
                self["label_value"].setText(value)
            elif field_name == "server_host":
                self["server_host_value"].setText(value)
            elif field_name == "server_port":
                self["server_port_value"].setText(value)
            elif field_name == "username":
                self["username_value"].setText(value)
            elif field_name == "password":
                self["password_value"].setText(value)
            elif field_name == "des_key":
                self["des_key_value"].setText(value)
        except Exception as e:
            print(f"Update field value error: {e}")

    def openChoiceMenu(self, item_name):
        try:
            if item_name == "protocol":
                choices = [(value, key) for key, value in self.protocol_choices.items()]
                current_choice = self.temp_protocol
            elif item_name == "destination":
                choices = [(value, key) for key, value in self.destination_choices.items()]
                current_choice = self.temp_destination
            else:
                return
            
            def choiceCallback(result):
                if result:
                    selected_key = result[1]
                    if item_name == "protocol":
                        self.temp_protocol = selected_key
                        self["protocol_value"].setText(self.protocol_choices.get(selected_key, "CCCam"))
                    elif item_name == "destination":
                        self.temp_destination = selected_key
                        self["destination_value"].setText(self.destination_choices.get(selected_key, "OSCam"))
            
            self.session.openWithCallback(
                choiceCallback,
                ChoiceBox,
                title=f"Select {item_name.title()}",
                list=choices
            )
        except Exception as e:
            print(f"Open choice menu error: {e}")

    def toggleEnable(self):
        try:
            self.temp_enable = "0" if self.temp_enable == "1" else "1"
            self["enable_value"].setText(self.enable_choices.get(self.temp_enable, "Yes"))
        except Exception as e:
            print(f"Toggle enable error: {e}")

    def keyDelete(self):
        try:
            if self.current_field and self.current_field != "keyboard":
                if self.current_field in ["label", "server_host", "username", "password", "des_key", "server_port"]:
                    setattr(self, f"temp_{self.current_field}", "")
                    self.updateFieldValue(self.current_field, "")
                    self["status_label"].setText(f"Field {self.current_field} cleared")
        except Exception as e:
            print(f"Key delete error: {e}")

    def clearAllFields(self):
        try:
            self.temp_label = ""
            self.temp_server_host = ""
            self.temp_server_port = ""
            self.temp_username = ""
            self.temp_password = ""
            self.temp_des_key = ""
            
            self["label_value"].setText("")
            self["server_host_value"].setText("")
            self["server_port_value"].setText("")
            self["username_value"].setText("")
            self["password_value"].setText("")
            self["des_key_value"].setText("")
            
            self["status_label"].setText("All fields cleared")
            self.session.open(MessageBox, "✓ All fields have been cleared", MessageBox.TYPE_INFO, timeout=3)
        except Exception as e:
            print(f"Clear all fields error: {e}")

    def testConnection(self):
        try:
            host = self.temp_server_host.strip()
            port_str = self.temp_server_port.strip()
            
            if not host or not port_str:
                self.session.open(MessageBox, "Please enter valid host and port!", MessageBox.TYPE_INFO)
                return
            
            if not port_str.isdigit():
                self.session.open(MessageBox, "Port must be a number!", MessageBox.TYPE_ERROR)
                return
            
            port = int(port_str)
            if port <= 0 or port > 65535:
                self.session.open(MessageBox, "Port must be between 1 and 65535!", MessageBox.TYPE_ERROR)
                return
            
            self["connection_status"].setText(f"Testing connection to {host}:{port}...")
            
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            result = sock.connect_ex((host, port))
            sock.close()
            
            if result == 0:
                self["connection_status"].setText(f"✓ Connection successful to {host}:{port}")
                self.session.open(MessageBox, f"✓ Connection successful to {host}:{port}", MessageBox.TYPE_INFO)
            else:
                self["connection_status"].setText(f"✗ Connection failed (Error: {result})")
                self.session.open(MessageBox, f"✗ Connection failed to {host}:{port} (Error: {result})", MessageBox.TYPE_ERROR)
            
        except ValueError:
            self.session.open(MessageBox, "Invalid port number!", MessageBox.TYPE_ERROR)
            self["connection_status"].setText("✗ Invalid port number")
        except Exception as e:
            self.session.open(MessageBox, f"Connection error: {str(e)}", MessageBox.TYPE_ERROR)
            self["connection_status"].setText("✗ Connection error")

    def showMainMenu(self):
        try:
            menu = [
                ("Test Connection", "test_connection"),
                ("Backup Config", "backup_config"),
                ("Restore Config", "restore_config"),
                ("Advanced Settings", "advanced_settings"),
                ("Grid Help", "grid_help"),
                ("Check Updates", "check_updates"),
            ]
            
            def menuCallback(result):
                if result:
                    if result[1] == "test_connection":
                        self.testConnection()
                    elif result[1] == "backup_config":
                        self.backupConfig()
                    elif result[1] == "restore_config":
                        self.restoreConfig()
                    elif result[1] == "advanced_settings":
                        self.showAdvancedSettings()
                    elif result[1] == "grid_help":
                        self.showGridHelp()
                    elif result[1] == "check_updates":
                        self.checkForUpdates()
            
            self.session.openWithCallback(menuCallback, ChoiceBox, title="Main Menu", list=menu)
        except Exception as e:
            self.session.open(MessageBox, f"Error showing menu: {str(e)}", MessageBox.TYPE_ERROR)

    def showGridHelp(self):
        help_text = """Grid Interface Guide:

Navigation:
← → ↑ ↓ - Move between grid cells
OK - Edit selected field
Back - Close/Exit
Red - Clear selected field
Green - Save configuration
Yellow - Test connection
Blue - Clear all fields
Menu - Open main menu

Field Types:
• Text Fields (Label, Host, Username, etc.) - Press OK to edit
• Selection Fields (Protocol, Destination) - Press OK on button to select
• Toggle Field (Enable) - Press OK on button to toggle

Virtual Keyboard:
• Special button to open full keyboard
• Supports uppercase, lowercase, symbols, numbers
• Easy text input for all fields

Grid Layout:
• Organized in 5x2 grid for easy navigation
• Each field has: Label, Value, Edit button
• Red highlight box shows selected cell"""
        
        self.session.open(MessageBox, help_text, MessageBox.TYPE_INFO, timeout=10)

    def showAdvancedSettings(self):
        try:
            menu = [
                ("Auto-restart Softcam", "auto_restart"),
                ("Check Config Syntax", "check_syntax"),
                ("Multiple Servers", "multiple_servers"),
                ("Import from File", "import_from_file"),
                ("Export Config", "export_config"),
            ]
            
            def advancedMenuCallback(result):
                if result:
                    if result[1] == "auto_restart":
                        self.toggleAutoRestart()
                    elif result[1] == "check_syntax":
                        self.checkConfigSyntax()
                    elif result[1] == "multiple_servers":
                        self.manageMultipleServers()
                    elif result[1] == "import_from_file":
                        self.importFromFile()
                    elif result[1] == "export_config":
                        self.exportConfig()
            
            self.session.openWithCallback(advancedMenuCallback, ChoiceBox, title="Advanced Settings", list=menu)
        except Exception as e:
            self.session.open(MessageBox, f"Advanced settings error: {str(e)}", MessageBox.TYPE_ERROR)

    def toggleAutoRestart(self):
        try:
            auto_restart_file = "/etc/camconfig_auto_restart"
            if os.path.exists(auto_restart_file):
                os.remove(auto_restart_file)
                self.session.open(MessageBox, "✓ Auto-restart disabled", MessageBox.TYPE_INFO)
            else:
                with open(auto_restart_file, "w") as f:
                    f.write("1")
                self.session.open(MessageBox, "✓ Auto-restart enabled", MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, f"✗ Auto-restart error: {str(e)}", MessageBox.TYPE_ERROR)

    def checkConfigSyntax(self):
        try:
            destination = self.temp_destination
            file_path = self.get_file_path(destination)
            
            if not os.path.exists(file_path):
                self.session.open(MessageBox, f"Config file not found:\n{file_path}", MessageBox.TYPE_INFO)
                return
            
            with open(file_path, 'r') as f:
                content = f.read()
            
            if destination in ["oscam", "ncam"]:
                if "[reader]" in content:
                    self.session.open(MessageBox, "✓ Config syntax appears valid", MessageBox.TYPE_INFO)
                else:
                    self.session.open(MessageBox, "⚠ Warning: No [reader] sections found", MessageBox.TYPE_WARNING)
            elif destination == "mgcamd":
                if "CWS =" in content or "CWS_INCOMING_PORT =" in content:
                    self.session.open(MessageBox, "✓ Config syntax appears valid", MessageBox.TYPE_INFO)
                else:
                    self.session.open(MessageBox, "⚠ Warning: No CWS entries found", MessageBox.TYPE_WARNING)
        except Exception as e:
            self.session.open(MessageBox, f"✗ Error checking config: {str(e)}", MessageBox.TYPE_ERROR)

    def manageMultipleServers(self):
        self.session.open(MessageBox, "✓ Multiple servers feature coming soon!", MessageBox.TYPE_INFO)

    def importFromFile(self):
        self.session.open(MessageBox, "✓ Import from file feature coming soon!", MessageBox.TYPE_INFO)

    def exportConfig(self):
        try:
            import time
            export_dir = "/tmp/camconfig_export"
            if not os.path.exists(export_dir):
                os.makedirs(export_dir)
            
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            export_file = os.path.join(export_dir, f"config_export_{timestamp}.txt")
            
            with open(export_file, "w") as f:
                f.write("Universal Cam Config Export\n")
                f.write("="*50 + "\n")
                f.write(f"Export Date: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Version: {self.CURRENT_VERSION}\n")
                f.write("="*50 + "\n\n")
                f.write(f"Label: {self.temp_label}\n")
                f.write(f"Enable: {self.enable_choices.get(self.temp_enable, 'Yes')}\n")
                f.write(f"Protocol: {self.protocol_choices.get(self.temp_protocol, 'CCCam')}\n")
                f.write(f"Server Host: {self.temp_server_host}\n")
                f.write(f"Server Port: {self.temp_server_port}\n")
                f.write(f"Username: {self.temp_username}\n")
                f.write(f"Password: {self.temp_password}\n")
                f.write(f"DES Key: {self.temp_des_key}\n")
                f.write(f"Destination: {self.destination_choices.get(self.temp_destination, 'OSCam')}\n")
                f.write("="*50 + "\n")
            
            self.session.open(MessageBox, f"✓ Configuration exported to:\n{export_file}", MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, f"✗ Export failed: {str(e)}", MessageBox.TYPE_ERROR)

    def backupConfig(self):
        try:
            import time
            backup_dir = "/tmp/camconfig_backup"
            if not os.path.exists(backup_dir):
                os.makedirs(backup_dir)
            
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            backup_file = os.path.join(backup_dir, f"config_backup_{timestamp}.txt")
            
            with open(backup_file, "w") as f:
                f.write(f"label={self.temp_label}\n")
                f.write(f"enable={self.temp_enable}\n")
                f.write(f"protocol={self.temp_protocol}\n")
                f.write(f"server_host={self.temp_server_host}\n")
                f.write(f"server_port={self.temp_server_port}\n")
                f.write(f"username={self.temp_username}\n")
                f.write(f"password={self.temp_password}\n")
                f.write(f"des_key={self.temp_des_key}\n")
                f.write(f"destination={self.temp_destination}\n")
            
            self.session.open(MessageBox, f"✓ Configuration backed up to:\n{backup_file}", MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, f"✗ Backup failed: {str(e)}", MessageBox.TYPE_ERROR)

    def restoreConfig(self):
        try:
            backup_dir = "/tmp/camconfig_backup"
            if not os.path.exists(backup_dir):
                self.session.open(MessageBox, "No backup directory found!", MessageBox.TYPE_INFO)
                return
            
            import glob
            backup_files = glob.glob(os.path.join(backup_dir, "*.txt"))
            if not backup_files:
                self.session.open(MessageBox, "No backup files found!", MessageBox.TYPE_INFO)
                return
            
            menu = []
            for file_path in sorted(backup_files, reverse=True):
                filename = os.path.basename(file_path)
                menu.append((filename, file_path))
            
            def restoreFileCallback(result):
                if result:
                    try:
                        with open(result[1], "r") as f:
                            lines = f.readlines()
                        
                        for line in lines:
                            line = line.strip()
                            if "=" in line:
                                key, value = line.split("=", 1)
                                if key == "label":
                                    self.temp_label = value
                                    self["label_value"].setText(value)
                                elif key == "enable":
                                    self.temp_enable = value
                                    self["enable_value"].setText(self.enable_choices.get(value, "Yes"))
                                elif key == "protocol":
                                    self.temp_protocol = value
                                    self["protocol_value"].setText(self.protocol_choices.get(value, "CCCam"))
                                elif key == "server_host":
                                    self.temp_server_host = value
                                    self["server_host_value"].setText(value)
                                elif key == "server_port":
                                    self.temp_server_port = value
                                    self["server_port_value"].setText(value)
                                elif key == "username":
                                    self.temp_username = value
                                    self["username_value"].setText(value)
                                elif key == "password":
                                    self.temp_password = value
                                    self["password_value"].setText(value)
                                elif key == "des_key":
                                    self.temp_des_key = value
                                    self["des_key_value"].setText(value)
                                elif key == "destination":
                                    self.temp_destination = value
                                    self["destination_value"].setText(self.destination_choices.get(value, "OSCam"))
                        
                        self.session.open(MessageBox, "✓ Configuration restored successfully!", MessageBox.TYPE_INFO)
                    except Exception as e:
                        self.session.open(MessageBox, f"✗ Restore failed: {str(e)}", MessageBox.TYPE_ERROR)
            
            self.session.openWithCallback(restoreFileCallback, ChoiceBox, 
                                        title="Select backup file to restore", list=menu)
        except Exception as e:
            self.session.open(MessageBox, f"Restore error: {str(e)}", MessageBox.TYPE_ERROR)

    def saveConfig(self):
        try:
            if not self.temp_server_host.strip():
                self.session.open(MessageBox, "Server host cannot be empty!", MessageBox.TYPE_ERROR)
                return
            
            if not self.temp_server_port.strip() or not self.temp_server_port.isdigit():
                self.session.open(MessageBox, "Please enter a valid port number!", MessageBox.TYPE_ERROR)
                return
            
            port = int(self.temp_server_port)
            if port <= 0 or port > 65535:
                self.session.open(MessageBox, "Port must be between 1 and 65535!", MessageBox.TYPE_ERROR)
                return
            
            if not self.temp_username.strip():
                self.session.open(MessageBox, "Username cannot be empty!", MessageBox.TYPE_ERROR)
                return
            
            if not self.temp_password.strip():
                self.session.open(MessageBox, "Password cannot be empty!", MessageBox.TYPE_ERROR)
                return
            
            if self.temp_protocol in ["newcamd", "newcamd-s", "mgcamd"] and not self.temp_des_key.strip():
                self.session.open(MessageBox, "DES Key is required for Newcamd/MGcamd protocols!", MessageBox.TYPE_ERROR)
                return

            config.plugins.UniversalCamConfig.label.value = self.temp_label
            config.plugins.UniversalCamConfig.enable.value = self.temp_enable
            config.plugins.UniversalCamConfig.protocol.value = self.temp_protocol
            config.plugins.UniversalCamConfig.server_host.value = self.temp_server_host
            config.plugins.UniversalCamConfig.server_port.value = port
            config.plugins.UniversalCamConfig.username.value = self.temp_username
            config.plugins.UniversalCamConfig.password.value = self.temp_password
            config.plugins.UniversalCamConfig.des_key.value = self.temp_des_key
            config.plugins.UniversalCamConfig.destination.value = self.temp_destination

            config.plugins.UniversalCamConfig.label.save()
            config.plugins.UniversalCamConfig.enable.save()
            config.plugins.UniversalCamConfig.protocol.save()
            config.plugins.UniversalCamConfig.server_host.save()
            config.plugins.UniversalCamConfig.server_port.save()
            config.plugins.UniversalCamConfig.username.save()
            config.plugins.UniversalCamConfig.password.save()
            config.plugins.UniversalCamConfig.des_key.save()
            config.plugins.UniversalCamConfig.destination.save()

            reader_line = self.generate_reader_line()
            
            if not reader_line:
                self.session.open(MessageBox, "Failed to generate reader configuration!", MessageBox.TYPE_ERROR)
                return
            
            file_path = self.get_file_path(self.temp_destination)
            
            if self.temp_destination in ["oscam", "ncam"]:
                success = self.add_or_replace_oscam_reader(file_path, reader_line)
            elif self.temp_destination == "mgcamd":
                success = self.add_or_replace_mgcamd_reader(file_path, reader_line)
            else:
                success = False
            
            if success:
                self["status_label"].setText("✓ Configuration saved successfully!")
                self.session.open(MessageBox, 
                    "✓ Configuration saved successfully!\nPlease restart your Softcam to apply changes.", 
                    MessageBox.TYPE_INFO, timeout=5)
            else:
                self["status_label"].setText("⚠ Failed to write config file")
                self.session.open(MessageBox, 
                    "⚠ Configuration saved but failed to write to config file!\nPlease check file permissions.", 
                    MessageBox.TYPE_WARNING)
                    
        except ValueError as e:
            self.session.open(MessageBox, f"Invalid value: {str(e)}", MessageBox.TYPE_ERROR)
            self["status_label"].setText("✗ Invalid value error")
        except Exception as e:
            self.session.open(MessageBox, f"Error saving configuration: {str(e)}", MessageBox.TYPE_ERROR)
            self["status_label"].setText("✗ Save error")

    def get_file_path(self, destination):
        if destination == "oscam":
            return OSCAM_PATH
        elif destination == "ncam":
            return NCAM_PATH
        elif destination == "mgcamd":
            return MGCAMD_PATH
        return OSCAM_PATH

    def generate_reader_line(self):
        try:
            if self.temp_protocol in ["cccam", "cccam-s"]:
                return self.generate_cccam_reader()
            elif self.temp_protocol in ["newcamd", "newcamd-s", "mgcamd"]:
                return self.generate_newcamd_reader()
            else:
                return ""
        except Exception as e:
            print(f"Generate reader line error: {e}")
            return ""

    def generate_cccam_reader(self):
        try:
            reader_label = self.temp_label.replace(" ", "_") if self.temp_label else "CamServer"
            ssl_option = "ccckeepalive = 1\n"
            if "cccam-s" in self.temp_protocol:
                ssl_option = "ccckeepalive = 1\nssl = 1\n"
            
            return f"""
[reader]
label = {reader_label}
enable = {self.temp_enable}
protocol = cccam
device = {self.temp_server_host},{self.temp_server_port}
user = {self.temp_username}
password = {self.temp_password}
inactivitytimeout = 30
group = 1
cccversion = 2.3.2
disablecrccws = 1
cccmaxhop = 1
cccwantemu = 1
{ssl_option}audisabled = 1

"""
        except Exception as e:
            print(f"Generate CCCam reader error: {e}")
            return ""

    def generate_newcamd_reader(self):
        """توليد قارئ Newcamd"""
        try:
            reader_label = self.temp_label.replace(" ", "_") if self.temp_label else "CamServer"
            
            if self.temp_destination in ["oscam", "ncam"]:
                return f"""
[reader]
label = {reader_label}
enable = {self.temp_enable}
protocol = newcamd
device = {self.temp_server_host},{self.temp_server_port}
user = {self.temp_username}
password = {self.temp_password}
key = {self.temp_des_key}
inactivitytimeout = 0
disablecrccws = 1
disableserverfilter = 1
connectoninit = 1
group = 1

"""
            else:
                return f"CWS = {self.temp_server_host} {self.temp_server_port} {self.temp_username} {self.temp_password} {self.temp_des_key} 01 02 03 04 05 06 07 08 09 10 11 12 13 14 {self.temp_label}\n"
        except Exception as e:
            print(f"Generate Newcamd reader error: {e}")
            return ""

    def add_or_replace_oscam_reader(self, file_path, new_reader):
        try:
            reader_label = self.temp_label.replace(" ", "_") if self.temp_label else "CamServer"
            
            directory = os.path.dirname(file_path)
            if directory and not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)
            
            if not os.path.exists(file_path):
                with open(file_path, 'w') as f:
                    f.write(new_reader)
                return True
            
            with open(file_path, 'r') as f:
                content = f.read()
            
            regex = r'(\[reader\].*?label\s*=\s*' + re.escape(reader_label) + r'.*?)(?=\[reader\]|\Z)'
            match = re.search(regex, content, re.DOTALL | re.IGNORECASE)
            
            if match:
                old_reader_block = match.group(1)
                content = content.replace(old_reader_block, new_reader)
            else:
                if not content.endswith('\n\n'):
                    content += '\n'
                content += new_reader
            
            with open(file_path, 'w') as f:
                f.write(content)
            
            return True
        except Exception as e:
            print(f"Add/Replace OSCam reader error: {e}")
            return False

    def add_or_replace_mgcamd_reader(self, file_path, new_reader):
        try:
            username = self.temp_username
            
            directory = os.path.dirname(file_path)
            if directory and not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)
            
            if not os.path.exists(file_path):
                with open(file_path, 'w') as f:
                    f.write(new_reader)
                return True
            
            with open(file_path, 'r') as f:
                content = f.read()
            
            lines = content.split('\n')
            new_lines = []
            replaced = False
            
            for line in lines:
                if line.startswith("CWS = "):
                    parts = line.split()
                    if len(parts) >= 4 and parts[2] == username:
                        new_lines.append(new_reader.strip())
                        replaced = True
                    else:
                        new_lines.append(line)
                else:
                    new_lines.append(line)
            
            if not replaced:
                new_lines.append(new_reader.strip())
            
            with open(file_path, 'w') as f:
                f.write('\n'.join(new_lines))
            
            return True
        except Exception as e:
            print(f"Add/Replace MGcamd reader error: {e}")
            return False

    def close(self):
        try:
            if self.flickerTimer:
                self.flickerTimer.stop()
            
            changed = (
                self.temp_label != config.plugins.UniversalCamConfig.label.value or
                self.temp_enable != config.plugins.UniversalCamConfig.enable.value or
                self.temp_protocol != config.plugins.UniversalCamConfig.protocol.value or
                self.temp_server_host != config.plugins.UniversalCamConfig.server_host.value or
                self.temp_server_port != str(config.plugins.UniversalCamConfig.server_port.value) or
                self.temp_username != config.plugins.UniversalCamConfig.username.value or
                self.temp_password != config.plugins.UniversalCamConfig.password.value or
                self.temp_des_key != config.plugins.UniversalCamConfig.des_key.value or
                self.temp_destination != config.plugins.UniversalCamConfig.destination.value
            )
            
            if changed:
                def exit_confirm(result):
                    if result:
                        Screen.close(self)
                
                self.session.openWithCallback(exit_confirm, MessageBox, 
                    "⚠ You have unsaved changes.\nDo you want to exit without saving?", 
                    MessageBox.TYPE_YESNO)
            else:
                Screen.close(self)
        except Exception as e:
            print(f"Close error: {e}")
            Screen.close(self)

    def checkForUpdates(self):
        try:
            self["update_status_label"].setText("Checking for updates...")
            d = getPage(self.VERSION_URL.encode("utf-8"))
            d.addCallback(self.updateCheckCallback).addErrback(self.updateCheckError)
        except Exception as e:
            self["update_status_label"].setText("Update check failed")
            print(f"Check for updates error: {e}")

    def updateCheckCallback(self, data):
        try:
            latest_version = data.decode("utf-8").strip()
            if latest_version > self.CURRENT_VERSION:
                message = f"✓ New version {latest_version} is available.\nDo you want to update now?"
                
                def update_confirmation_callback(result):
                    if result:
                        self.performUpdate()
                    else:
                        self["update_status_label"].setText("Update cancelled.")
                
                self.session.openWithCallback(update_confirmation_callback, MessageBox, message, MessageBox.TYPE_YESNO)
            else:
                self["update_status_label"].setText("✓ No updates available.")
        except Exception as e:
            self["update_status_label"].setText("✗ Update check failed")
            print(f"Update check callback error: {e}")

    def updateCheckError(self, error):
        self["update_status_label"].setText("✗ Update check failed")
        print(f"Update check error: {error}")

    def performUpdate(self):
        try:
            self["update_status_label"].setText("Downloading update...")
            d = getPage(self.INSTALLER_URL.encode("utf-8"))
            d.addCallback(self.downloadInstallerCallback).addErrback(self.downloadInstallerError)
        except Exception as e:
            self.session.open(MessageBox, f"✗ Update error: {str(e)}", MessageBox.TYPE_ERROR)
            self["update_status_label"].setText("✗ Update failed")

    def downloadInstallerCallback(self, data):
        try:
            with open(INSTALLER_PATH, "wb") as f:
                f.write(data)
            os.chmod(INSTALLER_PATH, 0o755)
            self.executeInstaller()
        except Exception as e:
            self.session.open(MessageBox, f"✗ Failed to save installer: {e}", MessageBox.TYPE_ERROR)
            self["update_status_label"].setText("✗ Download failed")

    def downloadInstallerError(self, error):
        self.session.open(MessageBox, "✗ Failed to download installer.\nCheck your internet connection.", MessageBox.TYPE_ERROR)
        self["update_status_label"].setText("✗ Download failed")

    def executeInstaller(self):
        try:
            self["update_status_label"].setText("Installing update...")
            process = subprocess.run([INSTALLER_PATH], capture_output=True, text=True)
            
            if process.returncode == 0:
                self.session.open(MessageBox, "✓ Update successful!\nPlease reboot your receiver.", MessageBox.TYPE_INFO)
                self["update_status_label"].setText("✓ Update finished. Reboot to apply.")
            else:
                self.session.open(MessageBox, f"✗ Update failed!\nError: {process.stderr}", MessageBox.TYPE_ERROR)
                self["update_status_label"].setText("✗ Installation failed")
        except subprocess.CalledProcessError as e:
            self.session.open(MessageBox, f"✗ Update failed!\nError: {e.stderr}", MessageBox.TYPE_ERROR)
            self["update_status_label"].setText("✗ Installation failed")
        except Exception as e:
            self.session.open(MessageBox, f"✗ Update error: {e}", MessageBox.TYPE_ERROR)
            self["update_status_label"].setText("✗ Installation failed")


def main(session, **kwargs):
    session.open(UniversalCamConfigGridScreen)

def menu(menuid, **kwargs):
    if menuid == "mainmenu":
        return [("Universal Cam Config v2.1", main, "Configure any CCCam/Newcamd/MGcamd server with Grid Interface", 44)]
    return []

def Plugins(**kwargs):
    desc = "Configure any CCCam/Newcamd/MGcamd server with Grid Interface"
    return [
        PluginDescriptor(
            name="Universal Cam Config",
            description=desc,
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main,
            icon="plugin.png"
        ),
        PluginDescriptor(
            name="Universal Cam Config",
            description=desc,
            icon="plugin.png",
            where=PluginDescriptor.WHERE_MENU,
            fnc=menu
        )
    ]

if __name__ == "__main__":
    print("Universal Cam Config v2.1 Plugin - Test Mode")